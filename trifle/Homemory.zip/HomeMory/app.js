//app.js


App({
  globalData: {
    openid: "",
    homeId: "",
    homeName:"",
    userInfo: {},
    isNew: true,
    manager: "",
    isDebug: false
    //如果需要变为debug模式 将此处改为true就可以看不用访问服务器的版本进行修改页面
  },

  onLaunch: function(options) {

  }
})