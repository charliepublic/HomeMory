// pages/advice/advice.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  goback: function() {
    wx.navigateBack({

    })
  }
})