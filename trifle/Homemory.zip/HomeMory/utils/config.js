var config = {
  host: 'https://xcx.scuisdc.cn:8777'
}

module.exports = config